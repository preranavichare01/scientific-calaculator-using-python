package calculator;

public class square {
	public void squ(float a) {
		float r = a * a;
		System.out.println("square:" + r);
	}
}
