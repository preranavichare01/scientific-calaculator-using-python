package calculator;

public class subtraction {
	public void sub(float a, float b) {
		float r = a - b;
		System.out.println("subtraction:" + r);
	}
}
