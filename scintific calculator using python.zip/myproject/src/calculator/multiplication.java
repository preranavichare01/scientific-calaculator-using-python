package calculator;

public class multiplication {

	public void mul(float a, float b) {
		float r = a * b;
		System.out.println("multiplication:" + r);
	}
	}

