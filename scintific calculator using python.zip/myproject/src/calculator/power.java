package calculator;

public class power {
	public void powe(float a, float b) {

		System.out.println("Power:" + Math.pow(a, b));
	}
}
