package calculator;

public class division {
	public void div(float a, float b) {
		float r = a / b;
		System.out.println("Division:" + r);
	}
}
