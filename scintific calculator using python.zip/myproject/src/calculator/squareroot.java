package calculator;

public class squareroot {
	public void sqr(float a) {

		System.out.println("Square root:" + Math.sqrt(a));
	}
}
