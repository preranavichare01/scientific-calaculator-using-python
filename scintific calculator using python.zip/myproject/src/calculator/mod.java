package calculator;

public class mod {
	public void modr(float a, float b) {
		float r = a % b;
		System.out.println("Modification:" + r);
	}

}
