package calculator;

public class exponential {
	public void expo(float a) {

		System.out.println("Exponential:" + Math.exp(a));
	}
}
