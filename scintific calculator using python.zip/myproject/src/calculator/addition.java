package calculator;

public class addition {
	public void add(float a, float b) {
		float r = a + b;
		System.out.println("Addition:" + r);
	}

}
